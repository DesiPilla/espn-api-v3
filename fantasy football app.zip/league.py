from authorize import Authorize
from team import Team
import requests
from tabulate import tabulate as table

class League():
    
    def __init__(self, league_id, year, username = None, password = None):
        self.league_id = league_id
        self.year = year
        if username and password:
            client = Authorize(username, password)
            self.swid = client.swid
            self.espn_s2 = client.espn_s2
        else:
            self.swid = None
            self.espn_s2 = None            

        # ESPN Fantasy Football API v3 came out for seasons in 2019 and beyond. v2 is used up until 2018
        print('Fetching league...')
        if (self.year >= 2019):         # ESPN API v3
            self.url = "https://fantasy.espn.com/apis/v3/games/ffl/seasons/" + \
                str(self.year) + "/segments/0/leagues/" + str(self.league_id)
        else:                           # ESPN API v2
            self.url = "https://fantasy.espn.com/apis/v3/games/ffl/leagueHistory/" + \
                str(self.league_id) + "?seasonId=" + str(self.year)
        
        self.cookies = {'swid' : self.swid, 'espn_s2' : self.espn_s2};
        settings = requests.get(self.url, cookies = self.cookies, params = {'view' : 'mSettings'}).json()
        
        # Try navigating the settings tree. If an error occurs, the league is not accessible
        try:
            if self.year >= 2019:
                self.currentWeek = settings['scoringPeriodId']
                self.settings = settings['settings']
            else:
                self.currentWeek = settings[0]['scoringPeriodId']
                self.settings = settings[0]['settings']
            print('League authenticated!')
        except:
            raise Exception('ERROR: League is not accessible: swid and espn_s2 needed.')
        
        # Gather league information
        print('Gathering team information...')
        self.regSeasonWeeks = self.settings['scheduleSettings']['matchupPeriodCount']
        self.teamData = requests.get(self.url, cookies = self.cookies, params = {'view' : 'mTeam'}).json()
        print('Gathering matchup data...')
        self.matchupData = requests.get(self.url, cookies = self.cookies, params = {'view' : 'mMatchupScore'}).json()
        if year < 2019:
            self.teamData = self.teamData[0]
            self.matchupData = self.matchupData[0]        
                
        # Build league
        self.getTeamNames() 
        self.getRosterSettings() 
        self.buildTeams()
        print('League successfully built!')
        
        return
        
        
    def __repr__(self):
        """This is what is displayed when print(league) is entered """
        return 'League(%s, %s)' % (self.settings['name'], self.year, ) 
    
    def getRosterSettings(self):
        ''' This grabs the roster and starting lineup settings for the league
                - Grabs the dictionary containing the number of players of each position a roster contains
                - Creates a dictionary rosterSlots{} that only inlcludes slotIds that have a non-zero number of players on the roster
                - Creates a dictionary startingRosterSlots{} that is a subset of rosterSlots{} and only includes slotIds that are on the starting roster
                - Add rosterSlots{} and startingRosterSlots{} to the League attribute League.rosterSettings
        '''
        print('Gathering roster settings information...')
        
        # This dictionary maps each slotId to the position it represents
        self.rosterMap = { 0 : 'QB', 1 : 'TQB', 2 : 'RB', 3 : 'RB/WR', 4 : 'WR',
                           5 : 'WR/TE', 6 : 'TE', 7 : 'OP', 8 : 'DT', 9 : 'DE',
                           10 : 'LB', 11 : 'DL', 12 : 'CB', 13 : 'S', 14 : 'DB',
                           15 : 'DP', 16 : 'D/ST', 17 : 'K', 18 : 'P', 19 : 'HC',
                           20 : 'BE', 21 : 'IR', 22 : '', 23 : 'RB/WR/TE', 24 : ' '
                           }
        
        roster = self.settings['rosterSettings']['lineupSlotCounts']    # Grab the dictionary containing the number of players of each position a roster contains
        rosterSlots = {}                                                # Create an empty dictionary that will replace roster{}
        startingRosterSlots = {}                                        # Create an empty dictionary that will be a subset of rosterSlots{} containing only starting players
        for positionId in roster:
            if roster[positionId] != 0:                                 # Only inlclude slotIds that have a non-zero number of players on the roster
                rosterSlots[positionId] = roster[positionId]
                if positionId not in ['20', '21', '24']:              # Include all slotIds in the startingRosterSlots{} unless they are bench, injured reserve, or ' '
                    startingRosterSlots[positionId] = [roster[positionId], self.rosterMap[int(positionId)]]
        self.rosterSettings = {'rosterSlots' : rosterSlots, 'startingRosterSlots' : startingRosterSlots}    # Add rosterSlots{} and startingRosterSlots{} as a league attribute
        return  
    
    def getTeamNames(self):
        """ This function takes the teamData of a league and:
                - Finds the number of teams in the league
                - Creates a dictionary self.swids where the user SWID is the key and the user's full name is the value
                - Creates a dictionary self.teamNames where the teamIndex is the key and a list containing [ownerName, teamName] is the value
        """
        self.numTeams = len(self.teamData['teams'])          # Find the number of teams in the league
        
        self.swids = {}                                      # Create an empty swids dictionary
        for member in self.teamData['members']:              # Add each swid and ownerName to the swids dictionary
            self.swids[member['id']] = '%s %s' % (member['firstName'], member['lastName'])
        
        self.teamNames = {}                                  # Create an empty teamNames dictionary
        self.adjustIds= {}
        id = 1
        for team in self.teamData['teams']:
            if team['id'] != id:                                    # If the teamId is not what it is supposed to be...
                self.adjustIds[team['id']] = id                     # Save the incorrect teamId for future reference
                self.teamData['teams'][id - 1]['id'] = id           # Correct the teamId of the copied team
            else: 
                self.adjustIds[id] = id
            id += 1
        
        id = 1        
        for team in self.teamData['teams']:
            teamId = team['id']                                     # Get the teamId of each team
            name = '%s %s' % (team['location'], team['nickname'])   # Get the name of each team
            swid = team['primaryOwner']                             # Get the swid of each team
            owner = self.swids[swid]                                # Get the owner's name for each team
            self.teamNames[teamId] = owner                          # Populate the teamNames dictionary
            id += 1
        return
    
    def buildTeams(self):
        """ This function builds the Team objects for each team in the league """
        self.teams = {}                                                             # Create an empty teams dictionary
        matchupData = self.matchupData
        print("Current Week:",self.currentWeek)
        print('Building teams...')
        for teamId in range(1, self.numTeams + 1):
            team = Team(self.teamData['teams'][teamId-1])                           # Create a Team object for each team in the league
            team.nameOwner(self.teamNames[teamId])                                  # Name the team owner
            team.startingRosterSlots = self.rosterSettings['startingRosterSlots']   # Define the league startingRosterSlots setting for each team
            self.teams[teamId] = team                                               # Add each Team object to the teams dictionary
        
        
        print('Building schedule...')
        numMatchups = (self.currentWeek - 1)*self.numTeams // 2     # Determines the number of matchups that have been completed (not including the current week)
        for week in range(1, self.settings['scheduleSettings']['matchupPeriodCount'] + 1):
            # Build the matchups for every week
            if week < self.currentWeek:
                matchupData = requests.get(self.url, cookies = self.cookies, params = { 'view' : 'mMatchupScore', 'view' : 'mMatchup', 'scoringPeriodId': week }).json()
            else: 
                matchupData = self.matchupData
                
            
            
            print('\tBuilding week %d/%d...' % (week, self.settings['scheduleSettings']['matchupPeriodCount']))             
            for m in range((week-1)*self.numTeams // 2, (week)*self.numTeams // 2):  
                awayTeam = matchupData['schedule'][m]['away']           # Define the away team of the matchup
                homeTeam = matchupData['schedule'][m]['home']           # Define the home team of the matchup
                
                #awayId = awayTeam['teamId']                             # Define the teamIndex of the away team
                #homeId = homeTeam['teamId']                             # Define the teamIndex of the home team
                awayId = self.adjustIds[awayTeam['teamId']]
                homeId = self.adjustIds[homeTeam['teamId']]
                
                self.teams[awayId].schedule[week] = self.teams[homeId]  # Add this matchup to the schedule of the away team's Team object
                self.teams[homeId].schedule[week] = self.teams[awayId]  # Add this matchup to the schedule of the home team's Team object
                if m < numMatchups:
                    self.teams[awayId].addMatchup(awayTeam, week)       # Add this matchup to the away team's Team object
                    self.teams[homeId].addMatchup(homeTeam, week)       # Add this matchup to the home team's Team object            
            week += 1         
            
        return
            
    def loadWeeklyRosters(self, week):
        '''Sets Teams Roster for a Certain Week'''
        params = {'view': 'mRoster', 'scoringPeriodId': week}       # Specify the request parameters for the given week
        rosterData = requests.get(self.url, params = params, cookies = self.cookies).json() # Fetch roster data for the given week
        if self.year < 2019:
            rosterData = rosterData[0]                              # Adjust rosterData for ESPN API v2
        for teamId in self.teams:                                   # Fetch the roster of each team for the given week                 
            self.teams[teamId].fetchWeeklyRoster(rosterData['teams'][self.teams[teamId].teamId - 1]['roster'], week)
        return  
    
    def shiftKey(dictionary, shiftKey):
        ''' This function takes a dictionary and a shiftKey, and shifts all elements with a key greater than or equal
        to that key down by 1.
        Example: a = {1: 'a', 2: 'b', 3: 'c', 5: 'd', 6: 'e', 8: 'f'}
                 b = shiftKey(a, 4)
                     {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 7: 'f'}
                 c = shiftKey(b, 6)
                     {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 6: 'f'}
        '''
        newDict = {}
        for key, val in dictionary.items():
            if key < shiftKey:
                newDict[key] = val
            else:
                newDict[key-1] = val
        return newDict      
    
    
    ''' **************************************************
        *         Begin advanced stats methods           *
        ************************************************** '''
    
    def weeklyScore(self, teamId, week):
        ''' Returns the number of points scored by a team's starting roster for a given week. '''
        if week <= self.currentWeek:
            return self.teams[teamId].scores[week]
        else:
            return None
        
    def printWeeklyScores(self, teamId):
        ''' Prints all weekly scores for a given team. '''
        print('  ---',self.teams[teamId].teamName,'---')
        for week in range(1, self.currentWeek):
            score = self.weeklyScore(teamId, week)
            print('Week ', week, ': ', round(score, 1))
        sum = 0
        for i in range(1, self.currentWeek):
            sum += self.teams[teamId].scores[i]
        avg = sum/ (self.currentWeek - 1)
        print('-------------------------------','\nAvg. Score:', '%.2f' % avg)
        return
        
    def topPlayers(self, teamId, week, slotCategoryId, n):
        ''' Takes a list of players and returns a list of the top n players based on points scored. '''
        # Gather players of the desired position
        unsortedList = []
        for player in self.teams[teamId].rosters[week]:
            if slotCategoryId in player.eligibleSlots:
                unsortedList += [player]
                
        # Sort players by points scored
        sortedList = [unsortedList[0]]
        for player in unsortedList[1:]:
            for i in range(len(sortedList)):
                if (player.score >= sortedList[i].score):
                    sortedList = sortedList[:i] + [player] + sortedList[i:]
                    break
            if player not in sortedList:
                sortedList += [player]
        return sortedList[:n]
       
    def printWeeklyMatchResults(self, teamId):
        ''' Prints all weekly match results for a given team. '''
        team = self.teams[teamId]
        print('  ---',team.teamName,'---')
        for week in range(1, leg.currentWeek):
            print('Week',str(week+1),': ', end ="")
            print('%.2f' % team.scores[week], '-', '%.2f' % team.schedule[week].scores[week], end='')
            print('   vs.', team.schedule[week].owner[0])
        print('------------------------------------------------------------')
        print('Season Record:',str(team.wins),'-',str(team.losses),'-',str(team.ties)) 
    
    def bestTrio(self, teamId, week):
        ''' Returns the the sum of the top QB/RB/Reciever trio for a team during a given week. '''
        qb = self.topPlayers(teamId, week, 0, 1)[0].score
        rb = self.topPlayers(teamId, week, 2, 1)[0].score
        wr = self.topPlayers(teamId, week, 4, 1)[0].score
        te = self.topPlayers(teamId, week, 6, 1)[0].score
        bestTrio = round(qb + rb + max(wr, te), 2)
        return bestTrio  
    
    def weeklyFinish(self, teamId, week):
        ''' Returns the rank of a team based on the weekly score of a team for a given week. '''
        team = self.teams[teamId]                           # Get the Team object associated with the input teamId
        teamIds = list(range(1, self.numTeams + 1))         # Get a list of teamIds 
        teamIds.remove(team.teamId)                         # Remove the teamId of the working team from the list of teamIds
        weeklyFinish = 1                                    # Initialize the weeklyFinish to 1
        for teamId in teamIds:
            if (team.scores[week] != self.teams[teamId].scores[week]) and (team.scores[week] <= self.teams[teamId].scores[week]):
                weeklyFinish += 1;                          # Increment the weeklyFinish for every team with a higher weekly score
        return weeklyFinish
    
    def averageWeeklyFinish(self, teamId, week):
        ''' This function returns the average weekly finish of a team through a certain week '''
        finish = 0
        for wk in range(1, week + 1):
            finish += self.weeklyFinish(teamId, wk)
        return finish / week    
    
    def averageOpponentFinish(self,  teamId, week):
        ''' This function returns the average weekly finish of a team's weekly opponent through a certain week '''
        finish = 0
        for wk in range(1, week + 1):
            finish += self.weeklyFinish(self.teams[teamId].schedule[wk].teamId, wk)
        return finish / week     
    
    def teamWeeklyPRank(self, teamId, week):
        ''' Returns the power rank score of a team for a certain week. '''
        team = self.teams[teamId]
        
        # Points for score
        bestWeeklyScore = self.sortWeeklyScore(week)[1].scores[week]
        score = self.weeklyScore(teamId, week)
        pfScore = score / bestWeeklyScore * 70
        
        # Team Record score
        oppScore = team.schedule[week].scores[week]
        if score > oppScore:
            win = 5             # Team won this week
        if score == oppScore:
            win = 2.5           # Team tied this week
        else:
            win = 0             # Team lost this week
        bestScore = team.bestLineup(week)    # Best possible lineup for team
        oppBestScore = team.schedule[week].bestLineup(week)
        if bestScore > oppBestScore:
            luck = 10           # Team should have won if both lineups were their best
        elif bestScore > oppScore:
            luck = 5            # Team could have won if their lineup was its best
        else: 
            luck = 0            # Team could not have won
        multiplier = 1 + (win + luck) / 100
        
        # Best lineup score
        bestBestWeeklyScore = self.sortBestLineup(week)[1].scores[week]
        bestLineupScore = bestScore / bestBestWeeklyScore * 20
        
        # Dominance score
        if score > oppScore:
            dominance = (score - oppScore) / score * 10
        else:
            dominance = 0
            
        return pfScore*multiplier + bestLineupScore + dominance
    
    def teamTotalPRank(self, teamId, week):
        ''' Gets overall power ranking for a team. ''' 
        pRank = 0
        for wk in range(1, week+1):
            pRank += self.teamWeeklyPRank(teamId, wk)
        pRank += self.teamWeeklyPRank(teamId, week)*2
        if week > 1:
            pRank += self.teamWeeklyPRank(teamId, week-1)
            week += 1
        return pRank / (week + 2)
    
    def printPowerRankings(self, week):
        ''' Print my power rankings in a nice table. '''
        powerRankings = []
        for teamId in range(1, self.numTeams + 1):
            powerRankings += [[self.teamTotalPRank(teamId, week), self.teams[teamId]]]
        sortedRankings = sorted(powerRankings, key=lambda x: x[0], reverse=True)        
        powerRankingsTable = []
        for team in sortedRankings:
            powerRankingsTable += [[ team[1].teamName, team[0], team[1].owner ]]
        print('\n','Week ',week, '\n', table( powerRankingsTable, headers = ['Team', 'Power Index', 'Owner'], floatfmt = '.2f'))
        return powerRankingsTable
    
    def weeklyLuckIndex(self, teamId, week):
        ''' This function returns an index quantifying how 'lucky' a team was in a given week '''
        team = self.teams[teamId]
        opp = team.schedule[week]
    
        # Luck Index based on where the team and its opponent finished compared to the rest of the league  
        result = team.weeklyResult(week)
        place = self.weeklyFinish(teamId, week)
        if result == 1:                                 # If the team won...
            odds = (place - 1) / (self.numTeams - 2)    # Odds of this team playing a team with a higher score than it
            luckIndex = 5*odds                          # The worse the team ranked, the luckier they were to have won
        else:                                                           # if the team lost or tied...
            odds = (self.numTeams - place) / (self.numTeams - 2)    # Odds of this team playing a team with a lower score than it
            luckIndex = -5*odds                                          # The better the team ranked, the unluckier they were to have lost or tied
        if result == 0.5:                               # If the team tied...
            luckIndex /= 2                              # They are only half as unlucky, because tying is not as bad as losing
            
        # Luck Index based on how the team scored compared to its opponent
        teamScore = team.scores[week]
        avgScore = team.avgPointsFor(week)
        stdevScore = team.stdevPointsFor(week)
        if stdevScore != 0:
            zTeam = (teamScore - avgScore) / stdevScore     # Get z-score of the team's performance
            effect = zTeam/(3*stdevScore)*2                 # Noramlize the z-score so that a performance 3 std dev's away from the mean has an effect of 2 points on the luck index
            luckIndex += (effect / abs(effect)) * min(abs(effect), 2)   # The maximum effect is +/- 2
        
        oppScore = opp.scores[week]
        avgOpp = opp.avgPointsAllowed(week)
        stdevOpp = opp.stdevPointsAllowed(week)
        if stdevOpp != 0:
            zOpp = (oppScore - avgOpp) / stdevOpp                       # Get z-score of the opponent's performance
            effect = zOpp/(3*stdevOpp)*2                        # Noramlize the z-score so that a performance 3 std dev's away from the mean has an effect of 2 points on the luck index     
            luckIndex -= (effect / abs(effect)) * min(abs(effect), 2)   # The maximum effect is +/- 2
      
        return luckIndex
                         
    def seasonLuckIndex(self, teamId, week):
        ''' This function returns an index quantifying how 'lucky' a team was all season long (up to a certain week) '''
        luckIndex = 0
        for week in range(1, week + 1):
            luckIndex += self.weeklyLuckIndex(teamId, week)
        return luckIndex    
    
    def printLuckIndex(self, week):
        ''' This function prints the index quantifying how 'lucky' a team was all season long (up to a certain week) '''
        lucks = []
        for teamId in range(1, self.numTeams + 1):
            luck = self.seasonLuckIndex(teamId, week)
            lucks.append([self.teams[teamId].teamName, round(luck, 2), self.teams[teamId].owner])
        lucks.sort(key = lambda x: x[1], reverse = True)
        print('\nThrough Week %d\n'% (week), table(lucks, headers = ["Team", "Luck Index", "Owner"])) 
        return lucks
    
    def resultsTopHalf(self, teamId, week):
        ''' This function returns the number of wins and losses a team would have through a certain week
        if a win was defined as scoring in the top half of teams for that week. I.e., in an 8 person league, the
        4 teams that scored the most points would be granted a win, and the other 4 teams would be granted a loss.'''
        wins, losses = 0, 0
        for wk in range(1, week + 1):
            place = self.weeklyFinish(teamId, wk)
            if place <= self.numTeams // 2:
                wins += 1
            else:
                losses += 1
        return wins, losses        
    
    def expectedFinish(self, teamId, week):
        ''' Inputs: teamId, week (that just passed)
            Returns: numWins, numLosses, numTies
            This function estimates the results of every remaining matchup for a team
            based on the team's and its opponent's power ranking. These results are 
            added to the team's current matchup results.
        '''
        team = self.teams[teamId]
        wins = team.wins
        losses = team.losses
        ties = team.ties
        pRank = self.teamTotalPRank(teamId, week)
        for wk in range(week + 1, self.regSeasonWeeks + 1):
            oppId = self.getTeamId(team.schedule[wk])
            oppPRank = self.teamTotalPRank(oppId, week)
            if pRank > oppPRank:
                wins += 1
            elif pRank < oppPRank:
                losses += 1
            else:
                ties += 1
        return wins, losses, ties
    
    def printExpectedStandings(self, week):
        ''' Inputs: week that just passed
            Outputs: None (prints expected standings)
            This function predicts the expected final standings for a league based
            on the power rankings through a given week.
            This function does NOT account for tiebreakers.
        '''
        results = []
        for teamId in range(1, self.numTeams + 1):
            wins, losses, ties = self.expectedFinish(teamId, week)
            results += [[self.teams[teamId], wins, losses, ties]]
        results.sort(key=lambda x: x[1], reverse=True)              # Sort first based on win total
        results.sort(key=lambda x: x[2], reverse=False)             # Sort second based on loss total
        resultsTable = []
        for team in results:
            resultsTable += [[ team[0].teamName, team[1], team[2], team[3], team[0].owner ]]
        print('\nWeek', week, '\n', table( resultsTable, headers = ['Team', 'Wins', 'Losses', 'Ties', 'Owner'], floatfmt = '.2f'), '\n\n*These standings do not account for tiesbreakers')     
        
        return resultsTable
        
    def getTeamId(self, team):
        ''' Inputs: Team object
            Outputs: teamId
            This function finds and returns the teamId of a Team object
        '''
        for i in range(1, self.numTeams + 1):
            if self.teams[i] == team:
                return self.teams[i].teamId
    

    ''' **************************************************
        *          Begin stat sortitng methods           *
        ************************************************** '''  

    def dictValuesToList(self, dict):
        ''' Takes a dictionary and creates a list containing all values. '''
        list = []
        for value in dict.values():
            list += [value]  
        return list
    
    def listsToDict(self, keys, vals):
        ''' Takes a list of keys and a list of values and creates a dictionary. '''
        dict = {}
        for i in range(len(keys)):
            dict[keys[i]] = vals[i]
        return dict
    
    def sortWeeklyScore(self, week):
        ''' Sorts league teams for a given week based on weekly score (highest score is first). '''
        teams = self.dictValuesToList(self.teams)      
        sortedTeams = sorted(teams, key=lambda x: x.scores[week],
                              reverse=True)
        ranks = list(range(1, self.numTeams + 1))
        sortedTeamDict = self.listsToDict(ranks, sortedTeams)
        return sortedTeamDict
    

    def sortBestLineup(self, week):
        ''' Sorts league teams for a given week based on best possible lineup (highest score is first). '''
        teams = self.dictValuesToList(self.teams)      
        sortedTeams = sorted(teams, key=lambda x: x.bestLineup(week),
                              reverse=True)
        ranks = list(range(1, self.numTeams + 1))
        sortedTeamDict = self.listsToDict(ranks, sortedTeams)
        return sortedTeamDict   

    def sortOpponentScore(self, week):
        ''' Sorts league teams for a given week based on their opponent's score (highest opponent score is first). '''
        teams = self.dictValuesToList(self.teams)      
        sortedTeams = sorted(teams, key=lambda x: x.schedule[week].scores[week],
                              reverse=True)
        ranks = list(range(1, self.numTeams + 1))
        sortedTeamDict = self.listsToDict(ranks, sortedTeams)
        return sortedTeamDict
    
    def sortBestTrio(self, week):
        ''' Sorts league teams for a given week based on their best QB/RB/Receiver trio (highest score is first). '''
        teams = self.dictValuesToList(self.teams)      
        sortedTeams = sorted(teams, key=lambda x: x.bestTrio(week),
                              reverse=True)
        ranks = list(range(1, self.numTeams + 1))
        sortedTeamDict = self.listsToDict(ranks, sortedTeams)
        return sortedTeamDict
    
    def sortNumOut(week):
        ''' Sorts league teams for a given week based on the number of players who did not play (least injuries is first). '''
        teams = self.dictValuesToList(self.teams)      
        sortedTeams = sorted(teams, key=lambda x: x.numOut(week),
                              reverse=True)
        ranks = list(range(1, self.numTeams + 1))
        sortedTeamDict = self.listsToDict(ranks, sortedTeams)
        return sortedTeamDict
    
    def sortPositionScore(self, week, slotId):
        ''' Sorts league teams for a given week based on the average starting slotId points (highest score is first) '''  
        teams = self.dictValuesToList(self.teams)
        sortedTeams = sorted(teams, key=lambda x: x.avgStartingScore(week, slotId),
                              reverse=True)
        ranks = list(range(1, self.numTeams + 1))
        sortedTeamDict = self.listsToDict(ranks, sortedTeams)
        return sortedTeamDict    

    def sortBenchPoints(self, week):
        ''' Sorts league teams for a given week based on the total bench points (highest score is first). '''
        teams = self.dictValuesToList(self.teams)
        sortedTeams = sorted(teams, key=lambda x: x.totalBenchPoints(week),
                              reverse=True)
        ranks = list(range(1, self.numTeams + 1))
        sortedTeamDict = self.listsToDict(ranks, sortedTeams)
        return sortedTeamDict       

    def sortDifference(self, week):
        ''' Sorts league teams for a given week based on the the difference between their 
        best possible score and their actual score (lowest difference is first). '''
        teams = self.dictValuesToList(self.teams)
        sortedTeams = sorted(teams, key=lambda x: x.scores[week] - x.schedule[week].scores[week], reverse=True)
        ranks = list(range(1, self.numTeams + 1))
        sortedTeamDict = self.listsToDict(ranks, sortedTeams)
        return sortedTeamDict      
    
    def sortOverallRoster(self, week):
        ''' Sorts league teams for a given week based on total roster points (highest score is first). '''
        teams = self.dictValuesToList(self.teams)
        sortedTeams = sorted(teams, key=lambda x: (x.totalBenchPoints(week) + x.scores[week]), reverse=True)
        ranks = list(range(1, self.numTeams + 1))
        sortedTeamDict = self.listsToDict(ranks, sortedTeams)
        return sortedTeamDict        
            
    def printWeeklyStats(self, week):
        ''' Prints weekly stat report for a league during a given week. '''
        last = self.numTeams
        statsTable = [['Most Points Scored: ', self.sortWeeklyScore(week)[1].owner],
                       ['Least Points Scored: ', self.sortWeeklyScore(week)[last].owner],
                       ['Best Possible Lineup: ', self.sortBestLineup(week)[1].owner],
                       ['Best Trio: ', self.sortBestTrio(week)[1].owner],
                       ['Worst Trio: ', self.sortBestTrio(week)[last].owner],
                       ['Best Lineup Setter', self.sortDifference(week)[1].owner],
                       ['Worst Lineup Setter', self.sortDifference(week)[last].owner],
                       ['---------------------','----------------'],
                       ['Best QBs: ', self.sortPositionScore(week, 0)[1].owner],
                       ['Best RBs: ', self.sortPositionScore(week, 2)[1].owner],
                       ['Best WRs: ', self.sortPositionScore(week, 4)[1].owner], 
                       ['Best TEs: ', self.sortPositionScore(week, 6)[1].owner],
                       ['Best Flex: ', self.sortPositionScore(week, 23)[1].owner],
                       ['Best DST: ', self.sortPositionScore(week, 16)[1].owner],
                       ['Best K: ', self.sortPositionScore(week, 17)[1].owner],
                       ['Best Bench: ', self.sortBenchPoints(week)[1].owner],
                       ['---------------------','----------------'],
                       ['Worst QBs: ', self.sortPositionScore(week, 0)[last].owner],
                       ['Worst RBs: ', self.sortPositionScore(week, 2)[last].owner],
                       ['Worst WRs: ', self.sortPositionScore(week, 4)[last].owner], 
                       ['Worst TEs: ', self.sortPositionScore(week, 6)[last].owner],
                       ['Worst Flex: ', self.sortPositionScore(week, 23)[last].owner],
                       ['Worst DST: ', self.sortPositionScore(week, 16)[last].owner],
                       ['Worst K: ', self.sortPositionScore(week, 17)[last].owner],
                       ['Worst Bench: ', self.sortBenchPoints(week)[last].owner]]
        print('\n', table(statsTable, headers = ['Week ' + str(week), '']))   
    
        # ['Most Injuries: ', self.sortNumOut(week)[last].owner.split(' ')[0]],
        # ['Least Injuries: ', self.sortNumOut(week)[0].owner.split(' ')[0]],
        return statsTable